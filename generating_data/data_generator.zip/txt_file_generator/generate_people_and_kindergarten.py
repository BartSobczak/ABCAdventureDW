import random
import math


# TODO: test na 2000 przedszkoli, 1 100 000 dzieci, 1 100 000 enrollments, 1 100 000 rodziców



male_names = ["James", "John", "Robert", "Michael", "William", "David", "Richard", "Joseph", "Charles", "Thomas",
              "Daniel", "Matthew", "Christopher", "George", "Andrew", "Joshua", "Edward", "Brian", "Kevin", "Ronald",
              "Timothy", "Jason", "Jeffrey", "Ryan", "Jacob", "Gary", "Nicholas", "Eric", "Stephen", "Jonathan",
              "Larry", "Justin", "Scott", "Brandon", "Frank", "Benjamin", "Gregory", "Samuel", "Raymond", "Patrick",
              "Alexander", "Jack", "Dennis", "Jerry", "Tyler", "Aaron", "Henry", "Adam", "Douglas", "Nathan",
              "Peter", "Zachary", "Kyle", "Walter", "Harold", "Jeremy", "Ethan", "Carl", "Keith", "Roger", "Gerald",
              "Christian", "Terry", "Sean", "Arthur", "Lawrence", "Austin", "Joe", "Noah", "Jesse", "Albert", "Bryan",
              "Billy", "Bruce", "Willie", "Jordan", "Dylan", "Alan", "Ralph", "Gabriel", "Roy", "Juan", "Wayne",
              "Eugene", "Logan", "Randy", "Louis", "Russell", "Vincent", "Philip", "Bobby", "Johnny", "Howard",
              "Simon", "Tomas", "Quentin", "Garrett", "Calvin", "Simon", "Harrison", "Mitchell", "Gavin", "Travis",
              "Adrian", "Derek", "Joel", "Cameron", "Preston", "Drew", "Colton", "Trevor", "Landon", "Malcolm", "Liam",
              "Brent", "Damian", "Aidan", "Riley", "Kieran", "Nolan", "Conner", "Colin", "Donovan", "Wyatt", "Jayden",
              "Xavier", "Brady", "Griffin", "Finnegan", "Jared", "Lucian", "Gideon", "Jasper", "Kai", "Dante",
              "Simon", "Graham", "Ronan", "Nathaniel", "Spencer", "Cyrus", "Elias", "Milo", "Theodore", "Silas"]

female_names = ["Mary", "Patricia", "Jennifer", "Linda", "Elizabeth", "Barbara", "Susan", "Jessica", "Sarah", "Karen",
                "Nancy", "Lisa", "Betty", "Margaret", "Sandra", "Ashley", "Kimberly", "Emily", "Donna", "Michelle",
                "Dorothy", "Carol", "Amanda", "Melissa", "Deborah", "Stephanie", "Rebecca", "Sharon", "Laura",
                "Cynthia", "Kathleen", "Amy", "Shirley", "Angela", "Helen", "Anna", "Brenda", "Pamela", "Nicole",
                "Samantha", "Katherine", "Emma", "Ruth", "Christine", "Catherine", "Debra", "Rachel", "Carolyn",
                "Janet", "Virginia", "Maria", "Heather", "Diane", "Julie", "Joyce", "Victoria", "Kelly", "Christina",
                "Joan", "Evelyn", "Lauren", "Judith", "Olivia", "Frances", "Martha", "Cheryl", "Megan", "Andrea",
                "Hannah", "Jacqueline", "Ann", "Jean", "Alice", "Kathryn", "Gloria", "Teresa", "Doris", "Sara",
                "Janice", "Julia", "Marie", "Madison", "Grace", "Judy", "Theresa", "Beverly", "Denise", "Marilyn",
                "Amber", "Danielle", "Rose", "Brittany", "Diana", "Abigail", "Natalie", "Jane", "Lori", "Hannah",
                "Alicia", "Suzannah", "Eva", "Lillian", "Audrey", "Clara", "Violet", "Lucille", "Eleanor", "Stella",
                "Penelope", "Hazel", "Lila", "Nora", "Ruby", "Lydia", "Avery", "Sophie", "Isabelle", "Ava", "Sadie",
                "Adeline", "Mabel", "Ivy", "Camila", "Aurora", "Leah", "Zoe", "Nina", "Brooklyn", "Harper", "Madeline",
                "Delilah", "Elise", "Fiona", "Aria", "Evelyn", "Gabrielle", "Elaina", "Holly", "Isla", "Jasmine",
                "Kiara", "Lena", "Maya", "Naomi", "Olive", "Paige", "Quinn", "Rosalie", "Savannah", "Tessa",
                "Vivian", "Willow"]

surnames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "Garcia", "Rodriguez", "Wilson",
            "Martinez", "Anderson", "Taylor", "Thomas", "Hernandez", "Moore", "Martin", "Jackson", "Thompson", "White",
            "Lopez", "Lee", "Gonzalez", "Harris", "Clark", "Lewis", "Robinson", "Walker", "Perez", "Hall", "Young",
            "Allen", "Sanchez", "Wright", "King", "Scott", "Green", "Baker", "Adams", "Nelson", "Hill", "Ramirez",
            "Campbell", "Mitchell", "Roberts", "Carter", "Phillips", "Evans", "Turner", "Torres", "Parker", "Collins",
            "Edwards", "Stewart", "Flores", "Morris", "Nguyen", "Murphy", "Rivera", "Cook", "Rogers", "Morgan",
            "Peterson", "Cooper", "Reed", "Bailey", "Bell", "Gomez", "Kelly", "Howard", "Ward", "Cox", "Diaz",
            "Richardson", "Wood", "Watson", "Brooks", "Bennett", "Gray", "James", "Reyes", "Cruz", "Hughes", "Price",
            "Myers", "Long", "Foster", "Sanders", "Ross", "Morales", "Powell", "Sullivan", "Russell", "Ortiz",
            "Jenkins", "Gutierrez", "Perry", "Butler", "Barnes", "Fisher", "Henderson", "Coleman", "Simmons",
            "Patterson", "Jordan", "Reeves", "Stanley", "Gordon", "Bryant", "Alexander", "Russell", "Griffin", "Hayes",
            "Gibson", "Bryant", "Wagner", "Weaver", "Wells", "Banks", "Pierce", "Caldwell", "Thornton", "Davidson",
            "Holland", "Rice", "Brennan", "Bowers", "Santos", "Vaughn", "Huff", "Owens", "Cameron", "Parsons",
            "Mendoza", "Day", "Manning", "May", "McDaniel", "Cross", "Curtis", "Norton", "Gilbert", "Barrett",
            "Higgins", "Chavez", "Malone", "Cabrera", "Potter", "McCarthy", "Fleming"]

address_first_names = ["Main", "Maple", "Oak", "Elm", "Washington", "Cedar", "Pine", "Broad", "High", "First", "Park",
                       "Church", "Second", "Central",
                       "Lakeview", "Elmwood", "West", "Sunset", "Smith", "River", "Forest", "Grove", "Lincoln",
                       "Chestnut", "Hillcrest", "Maplewood",
                       "Jackson", "Spruce", "Franklin", "Prospect", "Willow", "Spring", "School", "Cherry", "Madison",
                       "Pleasant", "North", "Ridge", "Adams",
                       "Rosewood", "Market", "Hillside", "Woodland", "Jefferson", "Union", "Victoria", "Birch",
                       "Locust", "South", "Walnut"]

address_second_names = ["Street", "Drive", "Avenue", "Boulevard", "Lane", "Road", "Way", "Court", "Circle", "Terrace"]

kindergarten_first_names = ["Little", "Happy", "Sunny", "Clever", "Giggly", "Tiny", "Playful", "Bright", "Curious",
                            "Cheerful", "Funny", "Charming", "Adventurous", "Silly", "Joyful", "Sweet", "Bubbly",
                            "Creative", "Whimsical", "Lively", "Precious", "Brave", "Inquisitive", "Merry", "Magical",
                            "Imaginative", "Silly", "Gentle",
                            "Friendly", "Enchanted", "Caring", "Colorful", "Wiggly", "Kind", "Sparkling", "Curious",
                            "Cozy", "Delightful", "Daring", "Dreamy", "Bouncy", "Sunny", "Gleeful", "Snuggly",
                            "Radiant", "Sprightly", "Zany", "Vivacious"]

kindergarten_second_names = ["Rabbits", "Explorers", "Chicks", "Stars", "Adventurers", "Sprites", "Pals", "Wonders",
                             "Dreamers", "Builders", "Gems", "Sunbeams", "Whispers", "Pebbles", "Sprites", "Sparklers",
                             "Discoverers", "Companions", "Travelers", "Giggles", "Frogs", "Whirlwinds", "Glimmers",
                             "Rainbows", "Journeys", "Blossoms", "Treasures", "Buddies", "Clouds", "Hugs", "Magic",
                             "Bubbles", "Sunshine", "Cuddles", "Daisies", "Laughter", "Moonbeams", "Waves", "Friends",
                             "Flowers", "Puddles", "Breezes", "Wishes", "Kisses", "Twinkles", "Sprinkles", "Cupcakes",
                             "Giggles"]

all_pesels_in_database = []
child_pesels_in_database = []
parents_pesels_in_database = []
teachers_pesels_in_database = []
phones_in_database = []
parents_relationships_in_database = []
kindergarten_full_names_emails_in_database = []


# TODO: można to wykorzać do obliczania poprzedniego id, ale chyba wydajniejs będzie ze zmiennych
def find_last_id(file):
    max_id = -1

    for line in file:

        parts = line.split(';')
        # Extract the ID and convert it to an integer
        current_id = int(parts[0].strip())
        # Check if the current ID is greater than the max_id found so far
        if current_id > max_id:
            # If yes, update max_id
            max_id = current_id

    return max_id


def generate_random_number(n):
    return random.randint(0, n)


def generate_address(m, n):
    full_addresses = []
    addresses = []

    for first_name in address_first_names:
        for second_name in address_second_names:
            address = first_name + " " + second_name
            if address not in addresses:
                addresses.append(address)

    for i in range(100):
        for address in addresses:
            full_address = address + " " + str(generate_number_in_range(m, n)) + "/" + \
                           str(generate_number_in_range(m, n))
            if full_address not in addresses:
                full_addresses.append(full_address)

    return full_addresses


# if generate_email == 1 it also adds email to full_name
def generate_name_surname_gender(generate_email):
    full_names = []

    for name in male_names:
        for surname in surnames:
            full_name = name + "," + surname + "," + "male" + ","

            if generate_email == 1:
                full_name = full_name + name.lower() + "." + surname.lower() + str(generate_random_number(1000)) + \
                            "@gmail.com,"

            if full_name not in full_names:
                full_names.append(full_name)

    for name in female_names:
        for surname in surnames:
            full_name = name + "," + surname + "," + "female" + ","

            if generate_email == 1:
                full_name = full_name + name.lower() + "." + surname.lower() + str(generate_random_number(1000)) + \
                            "@gmail.com,"

            if full_name not in full_names:
                full_names.append(full_name)

    return full_names


def add_n_pesels_to_database(n_of_rows):
    pesel_counter = 0
    pesels = []

    while pesel_counter < n_of_rows:
        pesel = random.randint(10 ** 10, 10 ** 11 - 1)
        if pesel not in all_pesels_in_database:
            all_pesels_in_database.append(str(pesel))
            pesels.append(str(pesel))
            pesel_counter += 1

    return pesels


def add_phone_to_database(n_of_rows):
    phone_counter = 0
    phones = []

    while phone_counter < n_of_rows:
        phone_number = random.randint(100000000, 999999999)
        if phone_number not in phones_in_database:
            phones_in_database.append(str(phone_number))
            phones.append(str(phone_number))
            phone_counter += 1

    return phones


# parents in database ma liczbę peseli rodziców już wygenerowanych
def insert_children(n_of_rows, dest_file, generated_parents):
    file = open(dest_file, "w")

    children_fullnames_and_gender = generate_name_surname_gender(0)
    random.shuffle(children_fullnames_and_gender)
    generated_child_pesels = add_n_pesels_to_database(n_of_rows)
    addresses = generate_address(0, 100)
    random.shuffle(addresses)

    for i in range(n_of_rows):
        #print(i+generated_parents)
        child_pesels_in_database.append(generated_child_pesels[i])
        file.write(generated_child_pesels[i] + "," + parents_pesels_in_database[i + generated_parents] +
                   "," + children_fullnames_and_gender[i] + addresses[i] + '\n')

    file.close()


def insert_parents(n_of_rows, dest_file):
    file = open(dest_file, 'w')

    guardians_fullnames_and_gender = generate_name_surname_gender(1)
    random.shuffle(guardians_fullnames_and_gender)
    generated_guardians_pesels = add_n_pesels_to_database(n_of_rows)
    generated_guardians_phones = add_phone_to_database(n_of_rows)

    for i in range(n_of_rows):
        parents_pesels_in_database.append(generated_guardians_pesels[i])

        file.write(generated_guardians_pesels[i] + "," + guardians_fullnames_and_gender[i] + \
                   generated_guardians_phones[i] + "\n")

    file.close()


def generate_number_in_range(m, n):
    return random.randint(m, n)


def if_main_teacher(i):
    if i % 3 == 0:
        return 1

    return 0


# trzeba generować liczbę wierszy podzielną przez 3
def insert_teachers(n_of_rows, dest_file, n_of_generated_teachers):
    file = open(dest_file, "w")

    teachers_fullnames_and_gender = generate_name_surname_gender(1)
    random.shuffle(teachers_fullnames_and_gender)
    generated_teachers_pesels = add_n_pesels_to_database(n_of_rows)
    generated_teachers_phones = add_phone_to_database(n_of_rows)

    for i in range(n_of_rows):
        teachers_pesels_in_database.append(generated_teachers_pesels[i])

        file.write(generated_teachers_pesels[i] + "," + str(math.floor(int(i + n_of_generated_teachers) / 3)) + "," + \
                   teachers_fullnames_and_gender[i] + generated_teachers_phones[i] +\
                   "," + str(generate_number_in_range(1970, 1998)) + "\n")

    file.close()


def generate_kindergarten_name_email():
    full_names = []

    for first_name in kindergarten_first_names:
        for second_name in kindergarten_second_names:
            kindergarten_full_name_email = first_name + " " + second_name + ";" + \
                                           first_name.lower() + "." + second_name.lower() + "@gmail.com"
            if kindergarten_full_name_email not in kindergarten_full_names_emails_in_database:
                full_names.append(kindergarten_full_name_email)
                kindergarten_full_names_emails_in_database.append(kindergarten_full_name_email)

    return full_names


# TODO: każda dzielnica przynajmniej raz???
def select_district_id():
    return random.randint(0, 99)


# docelewo będzie ich 1000
def insert_kindergarten(n_of_rows, starting_index, dest_file):
    file = open(dest_file, "w")

    generated_addresses = generate_address(100, 200)
    random.shuffle(generated_addresses)
    generated_phones = add_phone_to_database(n_of_rows)

    for i in range(n_of_rows):
        file.write(str(i + starting_index) + ";" + str(select_district_id()) + ";" +
                   kindergarten_full_names_emails_in_database[i + starting_index] + ";" + generated_addresses[i] + ";" +
                   generated_phones[i] + '\n')

    file.close()


def update_kindergarten_address(dest_file, n_of_generated_kindergartens):
    file = open(dest_file, 'w')

    generated_addresses = generate_address(200, 300)
    random.shuffle(generated_addresses)

    for i in range(n_of_generated_kindergartens):
        file.write(str(i) + ";" + generated_addresses[i] + '\n')

    file.close()


generate_kindergarten_name_email()
random.shuffle(kindergarten_full_names_emails_in_database)
# TODO: inputy przechowywać w zmiennych
# pierwsze generowanie
insert_parents(20, "insert_parents1.txt")
insert_children(20, "insert_children1.txt", 0)
insert_kindergarten(10, 0, "insert_kindergarten1.txt")
insert_teachers(30, "insert_teachers1.txt", 0)

print("Parents pesels in database: " + str(len(parents_pesels_in_database)))
print("All pesels in database: " + str(len(all_pesels_in_database)))
print("All phones in database: " + str(len(phones_in_database)))
print("Child pesels in database: " + str(len(child_pesels_in_database)))

# drugie generowanie
insert_parents(1780, "insert_parents2.txt")
insert_children(1780, "insert_children2.txt", 20)
insert_kindergarten(90, 10, "insert_kindergarten2.txt")
insert_teachers(270, "insert_teachers2.txt", 30)

update_kindergarten_address("update_kindergarten_addresses.txt", 100)
print("All pesels in database: " + str(len(all_pesels_in_database)))
