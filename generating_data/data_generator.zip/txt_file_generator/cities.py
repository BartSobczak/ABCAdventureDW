#find city name based on the district id
def find_city(district_id):
    dct_id_int = int(district_id)
    if 0 <= dct_id_int <= 9: return "Warszawa"
    if 10 <= dct_id_int <= 19: return "Gdansk"
    if 20 <= dct_id_int <= 29: return "Bydgoszcz"
    if 30 <= dct_id_int <= 39: return "Krakow"
    if 40 <= dct_id_int <= 49: return "Poznan"
    if 50 <= dct_id_int <= 59: return "Katowice"
    if 60 <= dct_id_int <= 69: return "Wroclaw"
    if 70 <= dct_id_int <= 79: return "Szczecin"
    if 80 <= dct_id_int <= 89: return "Lodz"
    if 90 <= dct_id_int <= 99: return "Lublin"

CITIES_COEFF = {
    "Warszawa": 1.8,
    "Gdansk": 1.6,
    "Bydgoszcz": 1.4,
    "Krakow": 1.6,
    "Poznan": 1.5,
    "Katowice": 1.4,
    "Wroclaw": 1.6,
    "Szczecin": 1.4,
    "Lodz": 1.4,
    "Lublin": 1.3
}