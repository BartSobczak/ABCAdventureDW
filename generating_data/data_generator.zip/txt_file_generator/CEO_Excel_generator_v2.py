from openpyxl import load_workbook, Workbook
from openpyxl import load_workbook
from districts_dict import districts, get_district_coeff
from cities import CITIES_COEFF, find_city
import random

# base prices
TODDLER_B_P = 2800
JUNIOR_B_P = 2600
PRESCHOOLER_B_P = 2400
FULLDAY_B_P = 5200
HALFDAY_B_P = 4000
EXTENDED_B_P = 6500
DROP_IN_B_P = 4500
LOCATION_B_P = 1500


def append_to_excel(txt_filename, xlsx_filename):
    try:
        workbook = load_workbook(xlsx_filename)
    except FileNotFoundError:
        workbook = Workbook()
    worksheet = workbook.active

    # Write column names if the file is empty
    if worksheet.max_row == 1:
        column_names = [
            "Kindergarten ID", "Kindergarten name", "District", "City", "Location price",
            "Toddler age group price", "Junior age group price", "Preschooler age group price",
            "Full-day care type price", "Half-day care type price", "Extended care type price",
            "Drop-in care type price"
        ]
        for col, name in enumerate(column_names, start=1):
            worksheet.cell(row=1, column=col, value=name)

    with open(txt_filename, 'r') as txt_file:
        for line in txt_file:
            values = line.strip().split(';')
            kindergarten_id, district_id, kindergarten_name, address, phone, email = values
            district = districts[district_id]
            city = find_city(district_id)
            district_coeff = get_district_coeff(district_id)

            location_price = LOCATION_B_P * CITIES_COEFF[city] + LOCATION_B_P * district_coeff
            toddler_price = int(TODDLER_B_P + 100 * (random.uniform(0.3, 1.4)))
            junior_price = int(JUNIOR_B_P + 100 * (random.uniform(0.3, 1.4)))
            preschool_price = int(PRESCHOOLER_B_P + 100 * (random.uniform(0.5, 1.4)))
            fullday_price = int(FULLDAY_B_P + 100 * (random.uniform(0.6, 1.4)))
            halfday_price = int(HALFDAY_B_P + 100 * (random.uniform(0.5, 1.4)))
            extended_price = int(EXTENDED_B_P + 100 * (random.uniform(0.4, 1.4)))
            drop_in_price = int(DROP_IN_B_P + 100 * (random.uniform(0.3, 1.3)))

            # Append data to the next available row
            row = worksheet.max_row + 1
            worksheet.append([
                kindergarten_id, kindergarten_name, district, city, location_price,
                toddler_price, junior_price, preschool_price, fullday_price,
                halfday_price, extended_price, drop_in_price
            ])

    workbook.save(xlsx_filename)


append_to_excel("insert_kindergarten1.txt", "CEO_Excel.xlsx")
append_to_excel("insert_kindergarten2.txt", "CEO_Excel.xlsx")
