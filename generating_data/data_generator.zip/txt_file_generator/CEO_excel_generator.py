#CHANGE INPUT FILENAME HERE:
TXT_FILENAME = 'insert_kindergarten1.txt'
#CHANGE OUTPUT FILENAME HERE:
XLSX_FILENAME = "CEO_Excel.xlsx"
from districts_dict import districts, get_district_coeff
from cities import CITIES_COEFF,find_city
import random
import xlsxwriter
# final price = age group price + care type price + location price
# age group base prices (we later add a random number to it):
TODDLER_B_P = 2800
JUNIOR_B_P = 2600
PRESCHOOLER_B_P = 2400
# care type base prices (we later add a random number to it):
FULLDAY_B_P = 5200
HALFDAY_B_P = 4000
EXTENDED_B_P = 6500
DROP_IN_B_P = 4500
# location price(later multiplied by city coefficient and district coeff):
LOCATION_B_P = 1500


#1.initialize
workbook = xlsxwriter.Workbook(XLSX_FILENAME)
worksheet = workbook.add_worksheet("sheet_1")

#2.column names
worksheet.write(0,0,"Kindergarten ID")
worksheet.write(0,1,"Kindergarten name")
worksheet.write(0,2,"District")
worksheet.write(0,3,"City")
worksheet.write(0,4,"Location price")
worksheet.write(0,5,"Toddler age group price")
worksheet.write(0,6,"Junior age group price")
worksheet.write(0,7,"Preschooler age group price")
worksheet.write(0,8,"Full-day care type price")
worksheet.write(0,9,"Half-day care type price")
worksheet.write(0,10,"Extended care type price")
worksheet.write(0,11,"Drop-in care type price")

#3.open the file and read the data from it
txt_file = open(TXT_FILENAME, 'r')
row = 1
for line in txt_file:
    values = line.strip().split(';')
    kindergarten_id, district_id, kindergarten_name, address, phone, email = values
    #4.generate additional data not included in the txt
    district = districts[district_id]
    city = find_city(district_id)
    district_coeff = get_district_coeff(district_id)
    #4.1.generate the location price with the coefficients
    location_price = LOCATION_B_P * CITIES_COEFF[city] + LOCATION_B_P * district_coeff
    #4.2.generate the rest of the prices randomly 
    toddler_price = int(TODDLER_B_P + 100 * (random.uniform(0.3, 1.2)))
    junior_price = int(JUNIOR_B_P + 100 * (random.uniform(0.3, 1.2)))
    preschool_price = int(PRESCHOOLER_B_P + 100 * (random.uniform(0.5, 1.2)))
    fullday_price = int(FULLDAY_B_P + 100 * (random.uniform(0.6, 1.2)))
    halfday_price = int(HALFDAY_B_P + 100 * (random.uniform(0.5, 1.2)))
    extended_price = int(EXTENDED_B_P + 100 * (random.uniform(0.4, 1.2)))
    drop_in_price = int(DROP_IN_B_P + 100 * (random.uniform(0.3, 1.1)))
    #5.put all the necessary data into the excel file
    worksheet.write(row,0,kindergarten_id)
    worksheet.write(row,1,kindergarten_name)
    worksheet.write(row,2,district)
    worksheet.write(row,3,city)
    worksheet.write(row,4,location_price)
    worksheet.write(row,5,toddler_price)
    worksheet.write(row,6,junior_price)
    worksheet.write(row,7,preschool_price)
    worksheet.write(row,8,fullday_price)
    worksheet.write(row,9,halfday_price)
    worksheet.write(row,10,extended_price)
    worksheet.write(row,11,drop_in_price)
    row = row + 1
#6.close the file
workbook.close()