import pandas as pd
import random

ceo_excel_ids = []
ceo_excel_location_prices = []
ceo_excel_toddler_prices = []
ceo_excel_junior_prices = []
ceo_excel_preschooler_prices = []
ceo_excel_full_day_prices = []
ceo_excel_half_day_prices = []
ceo_excel_extended_prices = []
ceo_excel_drop_in_prices = []

file_path = 'CEO_Excel.xlsx'

df = pd.read_excel(file_path)

for column in df.columns:
    # Get the corresponding list of values for that column
    value_list = df[column].tolist()

    # Assign values based on column name
    if column == "Kindergarten ID":
        ceo_excel_ids = value_list
    elif column == "Location price":
        ceo_excel_location_prices = value_list
    elif column == "Toddler age group price":
        ceo_excel_toddler_prices = value_list
    elif column == "Junior age group price":
        ceo_excel_junior_prices = value_list
    elif column == "Preschooler age group price":
        ceo_excel_preschooler_prices = value_list
    elif column == "Full-day care type price":
        ceo_excel_full_day_prices = value_list
    elif column == "Half-day care type price":
        ceo_excel_half_day_prices = value_list
    elif column == "Extended care type price":
        ceo_excel_extended_prices = value_list
    elif column == "Drop-in care type price":
        ceo_excel_drop_in_prices = value_list

MAX_CHILDREN_PER_AGE_GROUP = 20
children_pesels = []
children_count = {}


# TODO: zmienić tę funckję tak, aby warunek max 20 dzieci na grupę wiekową dotyczył jednego roku
def handle_enrollment(starting_index, n_of_generated_kindergartens, year):
    global children_count

    # Generate random kindergarten ID
    kindergarten_id = random.randint(0, n_of_generated_kindergartens - 1)

    # Generate random age group
    age_group = random.randint(0, 2)

    # Generate random care type
    care_type = generate_care_type()

    # Check if maximum children limit is reached for the selected kindergarten, age group, and year
    if (kindergarten_id, age_group, year) not in children_count:
        children_count[(kindergarten_id, age_group, year)] = 1
    else:
        if children_count[(kindergarten_id, age_group, year)] >= MAX_CHILDREN_PER_AGE_GROUP:
            # If maximum limit is reached, recursively call handle_enrollment to try again
            return handle_enrollment(starting_index, n_of_generated_kindergartens, year)
        else:
            children_count[(kindergarten_id, age_group, year)] += 1

    return kindergarten_id, care_type, age_group


def read_children_pesel(children_insert_file):

    with open(children_insert_file, 'r') as file:

        for line in file:
            pesel = line.split(',')[0]
            children_pesels.append(pesel)

def generate_care_type():
    choices = [0, 1, 2, 3]
    weights = [60, 15, 20, 5]

    return random.choices(choices, weights=weights)[0]


def generate_year():
    return random.randint(2015, 2024)


def generate_rating(m, n):
    return random.randint(m, n)


# age group może być totalnie losowo
def select_age_group():
    return random.randint(0, 2)


def calculate_price(kindergarten_id, care_type_id, age_group):

    #print("kindergarten_id: " + str(kindergarten_id))

    care_type_factor = 0
    age_group_factor = 0

    if care_type_id == 0:
        care_type_factor = ceo_excel_full_day_prices[kindergarten_id]
    elif care_type_id == 1:
        care_type_factor = ceo_excel_half_day_prices[kindergarten_id]
    elif care_type_id == 2:
        care_type_factor = ceo_excel_extended_prices[kindergarten_id]
    elif care_type_id == 3:
        care_type_factor = ceo_excel_drop_in_prices[kindergarten_id]

    if age_group == 0:
        age_group_factor = ceo_excel_toddler_prices[kindergarten_id]
    elif age_group == 1:
        age_group_factor = ceo_excel_junior_prices[kindergarten_id]
    elif age_group == 2:
        age_group_factor = ceo_excel_preschooler_prices[kindergarten_id]

    price = ceo_excel_location_prices[kindergarten_id] + age_group_factor + care_type_factor

    return price


def recognize_age_group(age_group):
    if age_group == 0:
        return 'toddler'
    elif age_group == 1:
        return 'junior'
    elif age_group == 2:
        return "preschooler"


# TODO: sprawdzić ile jest wpisów dla tego samego kindergarten i każdej grupy wiekowej, musi być max 20 dzieci na grupę wiekową w jednym przedszkolu
# TODO: potrzebna będzie do tego funukcja (to tego todo powyżej)
# TODO: zaczynać od starting_index
def insert_enrollments(n_of_rows, starting_index, dest_file, n_of_generated_kindergartens):
    file = open(dest_file, "w")

    for i in range(n_of_rows):
        year = generate_year()
        kindergarten_id, selected_care_type, selected_age_group = handle_enrollment(starting_index, n_of_generated_kindergartens, year)
        price = calculate_price(kindergarten_id, selected_care_type, selected_age_group)

        age_group_name = recognize_age_group(selected_age_group)

        file.write(str(i + starting_index) + "," + str(kindergarten_id) + "," +
                   children_pesels[i + starting_index] + "," + str(selected_care_type) + ","
                   + str(year) + "," + age_group_name + "," + str(price) + "\n")
    file.close()


def rate_kindergarten(n_of_kindergartens_to_rate):

    return 1


def insert_ratings(n_of_rows, starting_id, dest_file):

    file = open(dest_file, "w")

    for i in range(n_of_rows):
        rated_kindergarten_id = rate_kindergarten(n_of_rows)
        file.write(str(i + starting_id) + "," + str(rated_kindergarten_id) + "," + str(generate_rating(4, 10)) + "," +
                   str(generate_rating(6, 10)) + "," + str(generate_rating(5, 10)) + "\n")  # zmienić enrollment_id

    file.close()



# pierwsze generowanie
print("ceo_excel" + str(len(ceo_excel_drop_in_prices)))
read_children_pesel("insert_children1.txt")
insert_enrollments(20, 0, "insert_enrollments1.txt", 10)
insert_ratings(18, 0, "insert_ratings1.txt")


print("ceo_excel" + str(len(ceo_excel_drop_in_prices)))
# TODO: zobaczyć, które poprzednio wygenerowane dane trzeba wczytywać
# drugie generowanie
read_children_pesel("insert_children2.txt")
insert_enrollments(1780, 20, "insert_enrollments2.txt", 100)
insert_ratings(1402, 18, "insert_ratings2.txt")
